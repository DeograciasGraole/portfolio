<?php
use app\Http\Controllers;
use App\Http\Controllers\Auth\LoginContoller;
use App\Http\Controllers\Auth\RegisterContoller;
use App\Http\Controllers\Auth\LogoutController;
use App\Http\Controllers\commentsController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\CreatePostController;
use App\Http\Controllers\DeletePostController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\DetailPostController;
use App\Http\Controllers\updateController;
use App\Models\Post;
use Illuminate\Support\Facades\Route;
use app\Http\Controllers\Controller;
Route::get('/', function () {
    $post=Post::get();
   
    return view('welcome',['posts'=>$post]);
})->name('home');
 //Login and register page 
Route::get('/login',[LoginContoller::class,'index'])->name('login')->middleware('guest');
Route::post('/login',[LoginContoller::class,'store'])->name('logIn')->middleware('guest');
Route::get('/register',[RegisterContoller::class,'index'])->name('registerPage')->middleware('guest');
//login and register Logic 
Route::post('/register',[RegisterContoller::class,'store'])->name('register')->middleware('guest');
//Logout
Route::post('/logout',[LogoutController::class,'store'])->name('logout');
//Dasboard
Route::get('/dashboard', [DashboardController::class, 'index'])->name('Dashboard')->middleware('auth');

//CreatePost 
Route::get('/createPost',[CreatePostController::class,'index'])->name('createPost');

Route::post('/createPost',[CreatePostController::class,'store'])->name('createPost2');


//PostDetail
Route::get('/postDetail/{post}', [DetailPostController::class, 'index'])->name('postDetail');



//comment 
Route::post('/comments',[commentsController::class,'store'])->name('writeComment');

//update
Route::get('/update/{post}',[updateController::class,'index'])->name('updateRoute')->middleware('auth');
Route::post('/update/{post}',[updateController::class,'store']);

//delete
Route::delete('/delete/{post}',[DeletePostController::class,'index'])->name('deletePost');
