<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class comment extends Model
{
    //
    protected $fillable=[
        'user_id',
        'body'
    ];

    public function user(){
        return $this->belongsTo(User::class);
    }

    public function posts()
{
    return $this->belongsTo(Post::class,'user_id');
}

}
