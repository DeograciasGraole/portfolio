<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;

class DeletePostController extends Controller
{
    //
    public function index(Post $post){

       
        // Using find and delete
        $id=$post->id; 
        $post = Post::find($id);
        $post->delete();
        return redirect()->back();
    }
}
