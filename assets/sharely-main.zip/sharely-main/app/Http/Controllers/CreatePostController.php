<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Post;
use App\Models\comment;
class CreatePostController extends Controller
{
    //
    public function index( Request $resquest){

        
   $userID=$resquest->user()->id;
   
   $UserPost = Post::where('user_id', $userID)->with('comments')->withCount('comments')->get();
   $totalComments = $UserPost->sum('comments_count');
   
   return view('MyAccount.createPost', [
    'userPosts' => $UserPost,
    'totalComments' => $totalComments
]);
    }
    public function Store(Request $resquest){
        $resquest->validate([
            'title'=>'required',
            'text'=>'required',
            'Image'=>'required|active_url'
          ]);

   $resquest->user()->posts()->create([
    'title'=>$resquest->title,
    'body'=>$resquest->text,
    'linkImage'=>$resquest->Image
   ]);





   
   return redirect()->route('createPost')->with('success', 'Post created!');

    }
}
