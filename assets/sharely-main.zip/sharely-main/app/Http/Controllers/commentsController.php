<?php

namespace App\Http\Controllers;

use App\Models\comment;
use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\User;
class commentsController extends Controller
{
    //
    public function store(Request $request){
  
        $request->validate([
            'comment'=>'required',
            'post_id' => 'required|exists:posts,id'
        ]);
        $post=Post::find($request->post_id);
        

        if(!$post){
            return back()->with('error', 'Post not found');
        }



    
         $post->comments()->create([
            'user_id'=>auth()->id(),
            'body'=>$request->comment

        ]);
         
        return  redirect()->route('postDetail',[$post->id]);


    }
    

    
}
