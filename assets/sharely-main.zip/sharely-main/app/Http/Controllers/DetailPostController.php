<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\User;
use App\Models\comment;
class DetailPostController extends Controller
{
    //
    public function index(Request $request, Post $post){
          
       // $comments=comment::where('post_id',$post->id)->get();
       
      //  $comments=$post->comments;
        $comments = $post->comments()->with('user')->orderBy('created_at')->paginate(3);
         
        return view('posts.details',['post'=>$post,'comments'=>$comments]);


    }
}
