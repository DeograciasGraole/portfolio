<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
class DashboardController extends Controller
{
    //
    public function index( Request $request ){
    $userID=$request->user()->id;
    $UserPost = Post::where('user_id', $userID)->with('comments')->withCount('comments')->paginate(4);
    $totalComments = $UserPost->sum('comments_count');

   
        
        return view('MyAccount.dashboard',['userPosts'=>$UserPost,'totalComments'=>$totalComments]);
    }
}
