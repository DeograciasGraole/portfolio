<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use  App\Models\Post;
class updateController extends Controller
{
    //
    public function index(Request $request ,Post $post){

        $userID=$request->user()->id;
        $UserPost = Post::where('user_id', $userID)->with('comments')->withCount('comments')->get();
        $totalComments = $UserPost->sum('comments_count');

         
        return view('MyAccount.update',['post'=>$post,'totalComments'=>$totalComments,'userPosts'=>$UserPost]);
    }
    public function store(Request $request,Post $post){



          $id=$post->id;
          
          Post::where('id',$id)->update(
            [
                'title'=>$request->title,
                'body'=>$request->text,
                'linkImage'=>$request->Image
            ]
            );
           
            return redirect()->route('Dashboard');
    }
}
