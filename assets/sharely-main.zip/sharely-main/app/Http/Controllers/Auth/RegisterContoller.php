<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use App\Models\User;
class RegisterContoller extends Controller
{
    //
    public function index(){
        return view('auth.registration');
    }
    public function store(Request $request){
       
          $request->validate([
             'name'=>'required',
             'email'=>'required|email',
             'password'=>'required|confirmed'

          ]);

    user::create(
        [
            'name'=>$request->name,
            'email'=>$request->email,
            'password'=>Hash::make($request->password)
        ]
        );

        auth()->attempt($request->only('email','password'));
        return redirect()->route('home');
    }
}
