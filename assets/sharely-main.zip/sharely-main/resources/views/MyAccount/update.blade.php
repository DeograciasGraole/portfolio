<x-header :userPosts="$userPosts" :totalComments="$totalComments">
    <!-- Main Content -->
  
        <!-- Create Post -->
        <h3 class="text-xl font-semibold mt-8">Update Post</h3>
        <div class="bg-white p-6 mt-4 rounded-lg shadow">
            <form action="{{route('updateRoute',$post->id)}}" method="post" class="space-y-4">
                @csrf
                <div>
                    <label class="block text-gray-700">Post Title</label>
                    <input type="text" value="{{$post->title}}"  name="title" class="w-full p-2 border rounded @error('title') border-red-500 @enderror" placeholder="Enter title">
                </div>
                <div>
                    <label class="block text-gray-700">Description</label>
                    <textarea name="text" class="w-full p-2 border rounded  @error('text') border-red-500 @enderror" placeholder="Enter description">
                        {{$post->body}}
                    </textarea>
                </div>
                <div>
                    <label class="block text-gray-700">URL</label>
                    <input type="text" value="{{$post->linkImage}}"   name="Image" class="w-full p-2 border rounded  @error('Image') border-red-500 @enderror" " placeholder="Enter URL">
                </div>
                <div>
                    <label class="block text-gray-700">Upload Image</label>
                    <input type="file" class="w-full p-2 border rounded">
                </div>

                
                    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Submit</button>
                
              
            </form>
        </div>

        <!-- User Posts -->
        {{-- <h3 class="text-xl font-semibold mt-8">My Posts</h3>
        <div class="bg-white p-6 mt-4 rounded-lg shadow">
            <table class="w-full text-left">
                <thead>
                    <tr>
                        <th class="py-2">Image</th>
                        <th class="py-2">Title</th>
                        <th class="py-2">Likes</th>
                        <th class="py-2">Comments</th>
                        <th class="py-2">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="border-t">
                        <td class="py-2"><img src="https://via.placeholder.com/50" class="rounded"/></td>
                        <td class="py-2">How to Learn Tailwind CSS</td>
                        <td class="py-2">150</td>
                        <td class="py-2">30</td>
                        <td class="py-2">
                            <button class="text-blue-500">Edit</button>
                            <button class="text-red-500 ml-2">Delete</button>
                        </td>
                    </tr>
                    <tr class="border-t">
                        <td class="py-2"><img src="https://via.placeholder.com/50" class="rounded"/></td>
                        <td class="py-2">Building a Blog with Laravel</td>
                        <td class="py-2">90</td>
                        <td class="py-2">20</td>
                        <td class="py-2">
                            <button class="text-blue-500">Edit</button>
                            <button class="text-red-500 ml-2">Delete</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div> --}}


</x-header>
