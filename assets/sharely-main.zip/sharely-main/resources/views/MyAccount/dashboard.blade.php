<x-header :userPosts="$userPosts" :totalComments="$totalComments">
     <!-- Main Content -->
   
       

        <!-- User Posts -->
        <h3 class="text-xl font-semibold mt-8">My Posts</h3>
        <div class="bg-white p-6 mt-4 rounded-lg shadow">
            <table class="w-full text-left">
                <thead>
                    <tr>
                        <th class="py-2">Image</th>
                        <th class="py-2">Title</th>
                        <th class="py-2">Likes</th>
                        <th class="py-2">Comments</th>
                        <th class="py-2">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($userPosts as $UserPost )
                    <tr class="border-t">
                        <td class="py-2">
                            <img src="{{$UserPost->linkImage}}" 
                                 class="rounded-full w-16 h-16 object-cover" />
                        </td>
                        <td class="py-2">{{$UserPost->title}}</td>
                        <td class="py-2">0</td>
                        <td class="py-2">{{$UserPost->comments->count()}}</td>
                        <td class="py-2">
                            <div class="flex space-x-2">
                                <!-- Edit Form (POST method) -->
                                <form method="get" action="{{ route('updateRoute', $UserPost->id)}}">
                                    @csrf
                                    <button type="submit" class="text-blue-500">Edit</button>
                                </form>
                                
                        
                                <!-- Delete Form (DELETE method) -->
                                <form method="post" action="{{route('deletePost',$UserPost->id)}}">
                                    @method('DELETE')
                                    @csrf
                                    <!-- This is necessary to simulate a DELETE request -->
                                    <button type="submit" class="text-red-500">Delete</button>
                                </form>
                            </div>
                        </td>
                        
                    </tr>
                    
                    @endforeach
                 
                   
                </tbody>
               
            </table>
            {{$userPosts->links()}}
        </div>
    

</x-header>