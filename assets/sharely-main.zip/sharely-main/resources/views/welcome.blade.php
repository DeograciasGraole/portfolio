<x-layout>
    <!-- Hero Section -->
    <header class="hero-header bg-blue-500 text-white py-20">
        <div class="container mx-auto text-center">
            <h2 class="text-5xl font-bold mb-4">Welcome to Sharely 🚀</h2>
            <p class="text-xl">A place to share insights, tips, and tricks in the tech world.</p>
        </div>
    </header>

  

    <!-- Blog List Section with Sidebar -->
    <section class="py-16 bg-gray-50">
        <div class="container mx-auto px-4 grid grid-cols-1 lg:grid-cols-4 gap-10">
            <!-- Blog List -->
            <div class="lg:col-span-3 bg-white p-8 rounded-2xl shadow-md" data-aos="fade-up">
                <h2 class="text-4xl font-bold mb-10 text-center text-gray-800">Latest in Tech</h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    @foreach ($posts as $post)
                        <div class="bg-white rounded-2xl shadow-md overflow-hidden hover:shadow-lg transition duration-300" data-aos="fade-up">
                            <img src="{{ $post->linkImage }}" class="w-full h-56 object-cover rounded-t-2xl">
                            <div class="p-6">
                                <h3 class="text-xl font-semibold text-gray-900 mb-3">{{ $post->title }}</h3>
                                <p class="text-gray-600 text-base">{{ Str::limit($post->body, 100, '...') }}</p>
                                <a href="{{ route('postDetail', $post) }}" class="text-blue-600 font-semibold hover:underline">Read More</a>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
            
            <!-- Most Popular Topics Sidebar -->
            <aside class="bg-white rounded-2xl shadow-md p-6 h-fit" data-aos="fade-left">
                <h3 class="text-2xl font-semibold text-gray-800 mb-6">🔥 Most Popular Topics</h3>
                <div class="grid grid-cols-2 gap-4">
                    @php
                        $topics = ['JavaScript', 'Python', 'AI', 'Web Dev', 'React', 'Flutter', 'Cybersecurity'];
                    @endphp
                    @foreach ($topics as $topic)
                        <span class="bg-blue-500 text-white text-sm font-semibold px-4 py-2 rounded-full text-center">{{ $topic }}</span>
                    @endforeach
                </div>
            </aside>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-900 text-white py-8 mt-16">
        <div class="container mx-auto text-center">
            <p class="text-lg font-light">&copy; 2025 Sharely. All Rights Reserved.</p>
            <p class="mt-2 text-sm">
                <a href="privacy.html" class="hover:text-blue-400">Privacy Policy</a> |
                <a href="terms.html" class="hover:text-blue-400">Terms of Service</a>
            </p>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
        var swiper = new Swiper('.swiper-container', {
            slidesPerView: 1,
            spaceBetween: 10,
            autoplay: { delay: 3000 },
            breakpoints: {
                640: { slidesPerView: 2 },
                1024: { slidesPerView: 3 }
            }
        });
    </script>
</x-layout>