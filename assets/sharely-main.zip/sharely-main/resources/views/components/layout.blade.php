<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Sharely - Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:300;400;600;700&display=swap" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
    @vite('resources/css/app.css')
    <style>
        .hero-header {
            background-image: url('https://img.freepik.com/free-photo/glasses-lie-laptop-reflecting-light-from-screen-dark_169016-52267.jpg?t=st=1741876141~exp=1741879741~hmac=3ebfe1c8ef3750a9072a458efe9147f36a30afeb4a12bb41c80f83ab71780ae2&w=1380'); /* New techy background image */
            /* https://img.freepik.com/free-photo/glasses-lie-laptop-reflecting-light-from-screen-dark_169016-52267.jpg?t=st=1741876141~exp=1741879741~hmac=3ebfe1c8ef3750a9072a458efe9147f36a30afeb4a12bb41c80f83ab71780ae2&w=1380 */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            height: 75vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: white;
            text-shadow: 0 3px 6px rgba(0, 0, 0, 0.7);
            text-align: center;
        }

        .hero-header h2 {
            font-size: 4rem;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .hero-header p {
            font-size: 1.25rem;
            margin-top: 1rem;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }

        .navbar-link {
            transition: color 0.3s ease;
        }

        .navbar-link:hover {
            color: #4CAF50;
        }

        .blog-post {
            /* width: 400px;
            height:400px; */
            transition: transform 0.3s ease, box-shadow 0.3s ease;
           /* margin-left: 50px;
            margin-right: 50px; */
            border-radius: 10px;
            overflow: hidden;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .blog-post:hover {
            transform: translateY(-8px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
        }

        .blog-post img {
            transition: transform 0.3s ease;
        }

        .blog-post:hover img {
            transform: scale(1.05);
        }

        .blog-post h3 {
            font-size: 1.2rem;
            font-weight: bold;
            color: #333;
        }

        .blog-post .meta {
            font-size: 0.9rem;
            color: #666;
            margin-bottom: 10px;
        }

        .blog-post p {
            color: #444;
            font-size: 1rem;
            margin-bottom: 20px;
        }

        .footer {
            background-color: #333;
            color: #fff;
            padding: 40px 0;
            text-align: center;
        }

        .footer p {
            margin-bottom: 10px;
        }

        .footer a {
            color: #fff;
            text-decoration: underline;
            margin: 0 10px;
        }

        .footer a:hover {
            color: #4CAF50;
        }

        .btn-custom {
            padding: 10px 20px;
            border-radius: 30px;
            transition: background-color 0.3s ease;
        }

        .btn-blue { background-color: #007BFF; }
        .btn-green { background-color: #28A745; }
        .btn-yellow { background-color: #FFC107; }
        .btn-red { background-color: #DC3545; }

        .btn-custom:hover {
            opacity: 0.9;
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- Navbar -->
    <nav class="bg-gray-800 text-white shadow-md p-6">
        <div class="container mx-auto flex justify-between items-center">
            <a href="#" class="text-4xl font-bold navbar-link">Sharely</a>
            <div class="space-x-6 flex items-center">
                <a href="{{route('home')}}" class="navbar-link">Home</a>
                <a href="{{route('home')}}" class="navbar-link">About</a>
                <a href="{{route('home')}}" class="navbar-link">Contact</a>
                @if(!auth()->user())
                    <a href="{{route('login')}}" class="btn-custom btn-blue">Login</a>
                    <a href="{{route('registerPage')}}" class="btn-custom btn-green">Register</a>
                @else
                    <a href="{{route('Dashboard')}}" class="btn-custom btn-yellow">My Account</a>
                    <form action="{{route('logout')}}" method="post" class="inline-block">
                        @csrf
                        <button type="submit" class="btn-custom btn-red">Logout</button>
                    </form>
                @endif
            </div>
        </div>
    </nav>
    {{ $slot }}
    <script>
        document.querySelectorAll('.like-button').forEach(button => {
            button.addEventListener('click', function() {
                const likeCountSpan = this.nextElementSibling;
                let currentLikes = parseInt(likeCountSpan.textContent.split(' ')[0]);
                likeCountSpan.textContent = `${currentLikes + 1} Likes`;
            });
        });
    </script>
    
</body>
</html>