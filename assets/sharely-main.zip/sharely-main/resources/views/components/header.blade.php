<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>User Dashboard</title>
</head>
<body class="bg-gray-100 font-sans">
    <div class="flex h-screen">
        <!-- Sidebar -->
        <aside class="w-64 bg-white shadow-md p-6">
            <h1 class="text-xl font-bold">My Dashboard</h1>
            <nav class="mt-6">
                <ul>
                    <li class="mb-4"><a href="{{route('home')}}" class="text-gray-700 font-medium">🏠 Home</a></li>
                    <li class="mb-4"><a href="{{route('Dashboard')}}" class="text-gray-700 font-medium">📊 Dashboard</a></li>
                    <li class="mb-4"><a href="{{route('createPost')}}" class="text-gray-700 font-medium">📄 Create Posts</a></li>
                    <li class="mb-4"><a href="#" class="text-gray-700 font-medium">⚙️ Settings</a></li>
                </ul>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="flex-1 p-8">
            <h2 class="text-2xl font-semibold"> Welcome  @##{{auth()->user()->name}}</h2>
            
            <!-- Stats -->
            <div class="grid grid-cols-3 gap-6 mt-6">
                <div class="bg-white p-6 rounded-lg shadow">
                    <p class="text-gray-500">Total Posts</p>
                    <h3 class="text-2xl font-bold">{{$userPosts->count()}}</h3>
                </div>
                <div class="bg-white p-6 rounded-lg shadow">
                    <p class="text-gray-500">Total Likes</p>
                    <h3 class="text-2xl font-bold">0</h3>
                </div>
                <div class="bg-white p-6 rounded-lg shadow">
                    <p class="text-gray-500">Total Comments</p>
    
                    <h3 class="text-2xl font-bold">{{$totalComments}}</h3>
                </div>
            </div>
    
       {{ $slot }}
        </main>
    </div>
</body>
</html>
