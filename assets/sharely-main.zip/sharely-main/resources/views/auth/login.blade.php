<x-layout>

  <div class="min-h-screen flex items-center justify-center bg-gray-100">
    <div class="bg-white p-8 rounded-lg shadow-lg max-w-sm w-full">
      
      <h2 class="text-2xl font-bold text-center text-gray-800 mb-6">Login</h2>
      
      @session('status')
        <p class="text-red-600 text-center mb-4">{{ session('status') }}</p> 
      @endsession

      <form action="{{route('logIn')}}" method="POST">
        @csrf
        
        <div class="mb-4">
          <label for="username" class="block text-sm font-medium text-gray-700">Email</label>
          <input 
            type="email"
            id="username"
            name="email"
            value="{{old('email')}}"
            class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 @error('email') border-red-500 @enderror"
            placeholder="Enter your email"
          />
          @error('email')
            <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
          @enderror
        </div>

        <div class="mb-6">
          <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
          <input 
            type="password"
            id="password"
            name="password"
            class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 @error('password') border-red-500 @enderror"
            placeholder="Enter your password"
          />
          @error('password')
            <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
          @enderror
        </div>

        <button type="submit" class="w-full py-2 px-4 bg-blue-500 text-white font-semibold rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500">
          Log In
        </button>

        <div class="text-center mt-4">
          <p class="text-sm text-gray-600">
            Don't have an account? 
            <a href="signup.html" class="text-blue-500 hover:text-blue-600">Sign up</a>
          </p>
        </div>
      </form>
    </div>
  </div>

</x-layout>
