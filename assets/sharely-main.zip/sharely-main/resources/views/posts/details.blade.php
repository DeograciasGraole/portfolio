<!-- resources/views/blog/show.blade.php -->

<x-layout>
    <div class="container mx-auto py-12 p-10">
        <!-- Blog Post Content -->
        <div class="max-w-3xl mx-auto bg-white p-6 shadow-lg rounded-lg">
            <!-- Blog Image -->
            <img src="{{$post->linkImage}}" alt="Blog Post Image" class="w-full h-64 object-cover rounded-lg mb-6">

            <!-- Blog Post Title and Meta -->
            <h1 class="text-4xl font-bold mb-4">{{$post->title}}</h1>
            <div class="meta flex space-x-4 text-sm mb-6 text-gray-500">
                <small><i class="fa fa-calendar-alt"></i> {{$post->created_at->diffForHumans() }}</small>
                <small><i class="fa fa-user"></i> {{$post->user->name}}</small>
            
            </div>
            <p class="text-gray-700 mb-6">
               {{$post->body}}
            </p>
        </div>
        
        <!-- Comment Section -->
        <div class="max-w-3xl mx-auto bg-white p-6 shadow-lg rounded-lg mt-10">
            <h2 class="text-2xl font-semibold mb-4">Leave a Comment</h2>
   @auth
        <!-- Comment Form -->
        <form action="{{route('writeComment')}}" method="POST">
            @csrf
            <div class="mb-4 flex items-center space-x-4">
                <!-- Profile Picture (Placeholder) -->
                <img src="https://img.freepik.com/free-vector/hand-drawn-influencer-boy-illustration_23-2147998990.jpg?t=st=1742481932~exp=1742485532~hmac=83cc62a571cb8b397ead62054d759ada35e3c7223089bf11b0e4a855ddbe93a8&w=826" alt="User" class="w-10 h-10 rounded-full">
                <input type="hidden" name="post_id" value="{{$post->id}}">
                <div class="w-full">
                    <textarea id="comment"  name="comment" rows="4" class="w-full p-3 border borderr-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500   @error('comment')
                         border-red-500
                    @enderror" placeholder="Write your comment..."></textarea>
                </div>
            </div>

            <button type="submit" class="py-2 px-4 bg-blue-500 text-white rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500">
                Submit Comment
            </button>
        </form>
    </div>
   @endauth
           

        <!-- Display Comments -->
        <div class="max-w-3xl mx-auto bg-white p-6 shadow-lg rounded-lg mt-10">
            <h2 class="text-2xl font-semibold mb-4">Comments</h2>

            <!-- Example Comment -->
            <div class="comment mb-6">

                @foreach ($comments as $cmt )
                <div class="flex items-start space-x-4 mb-4">
                    <!-- Profile Picture -->
                    <img src="https://img.freepik.com/premium-vector/people-communication-icon-comic-style-people-vector-cartoon-illustration-pictogram-partnership-business-concept-splash-effect_157943-6552.jpg?w=826" alt="User" class="w-10 h-10 rounded-full">

                    <div class="w-full">
                        <!-- User Info and Comment -->
                        <div class="flex items-center justify-between mb-2">
                            <div class="font-semibold text-gray-800">
                                {{$cmt->user->name}}
                            
                            </div>
                            <div class="text-sm text-gray-500">{{$cmt->created_at->diffForHumans()}}</div>
                        </div>
                        <p class="text-gray-700 mb-2">
                        {{$cmt->body}}
                        </p>
                        <!-- Like & Reply Buttons (Optional) -->
                        <div class="flex space-x-6 text-sm text-gray-500">
                            <span><i class="fa fa-heart"></i> 5 Likes</span>
                            <span><i class="fa fa-comment"></i> 2 Replies</span>
                        </div>
                    </div>
                </div>
                @endforeach
                
            </div>

            <!-- Another Example Comment -->
           

            <!-- Add more comments dynamically here -->
        </div>
        {{ $comments->links() }}
    </div>
</x-layout>
